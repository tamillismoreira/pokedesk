public class Pokemon {
    
}
