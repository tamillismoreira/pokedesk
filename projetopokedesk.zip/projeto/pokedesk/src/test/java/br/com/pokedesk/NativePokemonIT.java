package br.com.pokedesk;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativePokemonIT extends PokemonTest {

    // Execute the same tests but in native mode.
}